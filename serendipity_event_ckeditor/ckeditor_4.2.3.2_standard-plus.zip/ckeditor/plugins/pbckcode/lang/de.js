﻿CKEDITOR.plugins.setLang("pbckcode","de",
{
	title: 'PBCKCODE',
	addCode : 'Code einfügen',
	editCode : 'Code editieren'
});