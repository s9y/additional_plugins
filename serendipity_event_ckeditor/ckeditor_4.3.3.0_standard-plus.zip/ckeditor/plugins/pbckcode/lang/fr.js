CKEDITOR.plugins.setLang("pbckcode","fr",
{
	title: 'PBCKCODE',
	addCode : 'Ajouter du code',
	editCode : 'Modifier ce code'
});