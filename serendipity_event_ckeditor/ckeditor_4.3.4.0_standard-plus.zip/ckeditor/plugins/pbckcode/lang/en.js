CKEDITOR.plugins.setLang("pbckcode","en",
{
	title: 'PBCKCODE',
	addCode : 'Add code',
	editCode : 'Edit code'
});