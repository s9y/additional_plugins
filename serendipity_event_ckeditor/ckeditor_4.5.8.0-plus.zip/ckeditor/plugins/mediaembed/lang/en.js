/**
 * @author Fabian Vogelsteller [frozeman.de]
 * @copyright Copyright (c) 2013 - Önder Ceylan. All rights reserved.
 * @version 0.6
 */

// set CKeditor lang
CKEDITOR.plugins.setLang( 'mediaembed', 'en', {
    toolbar: 'Embed Media',
    dialogTitle : 'Embed Media',
    dialogLabel : 'Paste Embed Code Here'
} );