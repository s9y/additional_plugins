/**
 * @author Alejandro Vasquez [neurotools.cl]
 * @copyright Copyright (c) 2013 - Önder Ceylan. All rights reserved.
 * @version 0.6
 */

// set CKeditor lang
CKEDITOR.plugins.setLang( 'mediaembed', 'es', {
    toolbar: 'Incrustar Medios',
    dialogTitle : 'Incrustar Medios',
    dialogLabel : 'Pegue el c&oacute;digo de incrustaci&oacute;n aqu&iacute;'
} );