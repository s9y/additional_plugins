<?php

@define('PLUGIN_EVENT_LDAP_TITLE', 'LDAP Authentication');
@define('PLUGIN_EVENT_LDAP_DESC', 'Adds support for authentication using LDAP.');

@define('PLUGIN_EVENT_LDAP_ENABLE', 'Enable');
@define('PLUGIN_EVENT_LDAP_ENABLE_DESC', 'Enable LDAP authentication.');
@define('PLUGIN_EVENT_LDAP_HOST', 'Server Host:');
@define('PLUGIN_EVENT_LDAP_HOST_DESC', 'LDAP server address.');
@define('PLUGIN_EVENT_LDAP_PORT', 'Server Port:');
@define('PLUGIN_EVENT_LDAP_PORT_DESC', 'Address that LDAP server is listening on.');
@define('PLUGIN_EVENT_LDAP_RDN', 'Relative Distinguished Name');
@define('PLUGIN_EVENT_LDAP_RDN_DESC', 'RDN to use to bind to server.');
@define('PLUGIN_EVENT_LDAP_TLS', 'Use TLS');
@define('PLUGIN_EVENT_LDAP_TLS_DESC', 'Use TLS encryption for communication with server.');
@define('PLUGIN_EVENT_LDAP_SYNC', 'Account Synchronization');
@define('PLUGIN_EVENT_LDAP_SYNC_DESC', 'Enable this option to update the LDAP server when the user changes their personal settings within S9Y (including password).  Also, this means that changing the LDAP access level attribute will immediately update the S9Y account (to promote or demote accounts outside S9Y).');

@define('PLUGIN_EVENT_LDAP_ATTR_PASSWORD', 'LDAP Attribute: Password');
@define('PLUGIN_EVENT_LDAP_ATTR_PASSWORD_DESC', "LDAP attribute holding the user's password.  This is only used if synchronization is enabled in order to update the password.");
@define('PLUGIN_EVENT_LDAP_ATTR_REALNAME', 'LDAP Attribute: Real Name');
@define('PLUGIN_EVENT_LDAP_ATTR_REALNAME_DESC', "LDAP attribute holding a user's real name.");
@define('PLUGIN_EVENT_LDAP_ATTR_EMAIL', 'LDAP Attribute: E-Mail');
@define('PLUGIN_EVENT_LDAP_ATTR_EMAIL_DESC', "LDAP attribute holding a user's e-mail address");
@define('PLUGIN_EVENT_LDAP_ATTR_ACCESS_LEVEL', 'LDAP Attribute: Access Level');
@define('PLUGIN_EVENT_LDAP_ATTR_ACCESS_LEVEL_DESC', 'LDAP attribute holding user access level.');

@define('PLUGIN_EVENT_LDAP_DEFAULT_ACCESS_LEVEL', 'Default: Access Level');
@define('PLUGIN_EVENT_LDAP_DEFAULT_ACCESS_LEVEL_DESC', "If no LDAP attribute indicates a user's access level, this setting controls the default access level for new users.");
@define('PLUGIN_EVENT_LDAP_DEFAULT_WYSIWYG', 'Default: Use WYSIWYG');
@define('PLUGIN_EVENT_LDAP_DEFAULT_WYSIWYG_DESC', 'For new users, enable WYSIWYG by default.');
@define('PLUGIN_EVENT_LDAP_DEFAULT_SEND_COMMENTS', 'Default: Send Comments');
@define('PLUGIN_EVENT_LDAP_DEFAULT_SEND_COMMENTS_DESC', 'For new users, send comments by default.');
@define('PLUGIN_EVENT_LDAP_DEFAULT_SEND_TRACKBACK', 'Default: Send Trackbacks');
@define('PLUGIN_EVENT_LDAP_DEFAULT_SEND_TRACKBACK_DESC', 'For new users, send trackbacks by default.');
@define('PLUGIN_EVENT_LDAP_DEFAULT_FORBID_CREATING', 'Default: Forbid Creating');
@define('PLUGIN_EVENT_LDAP_DEFAULT_FORBID_CREATING_DESC', 'For new users, forbid creating entries.');
@define('PLUGIN_EVENT_LDAP_DEFAULT_ALLOW_PUBLISHING', 'Default: Allow Publishing');
@define('PLUGIN_EVENT_LDAP_DEFAULT_ALLOW_PUBLISHING_DESC', 'For new users, allow publishing entries.');

@define('PLUGIN_EVENT_LDAP_USERLEVEL_DENY', 'Deny');

@define('PLUGIN_EVENT_LDAP_DEBUG', 'Enable Debug Logging');
@define('PLUGIN_EVENT_LDAP_DEBUG_DESC',  "Write debugging information to the log file '/tmp/s9yldap.log'.");

@define
?>