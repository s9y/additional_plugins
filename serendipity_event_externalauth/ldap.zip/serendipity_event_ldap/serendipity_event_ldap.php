<?php

// Probe for a language include with constants. Still include defines later on, if some constants were missing
$probelang = dirname(__FILE__) . '/' . $serendipity['charset'] . 'lang_' . $serendipity['lang'] . '.inc.php';
if (file_exists($probelang))
{
	include $probelang;
}

include dirname(__FILE__) . '/lang_en.inc.php';

class serendipity_event_ldap extends serendipity_event
{
	var $title = PLUGIN_EVENT_LDAP_TITLE;

	function introspect(&$propbag)
	{
		global $serendipity;

		$propbag->add('name',          PLUGIN_EVENT_LDAP_TITLE);
		$propbag->add('description',   PLUGIN_EVENT_LDAP_DESC);
		$propbag->add('stackable',     false);
		$propbag->add('author',        'Jonathan Van Eenwyk');
		$propbag->add('version',       '1.0');
		$propbag->add('requirements',  array(
			'serendipity' => '0.8',
			'smarty'      => '2.6.7',
			'php'         => '4.1.0'
		));
		$propbag->add('event_hooks',    array(
			'backend_auth'         => true,
			'backend_auth_verify'  => true,
			'backend_users_edit'   => true
		));
		$propbag->add('configuration', array(
			'enable', 'host', 'port', 'rdn', 'tls', 'enable_sync',
			'attr_password', 'attr_realname', 'attr_email', 'attr_access_level',
			'default_access_level', 'default_wysiwyg', 'default_send_comments', 'default_send_trackback', 'default_forbid_creating', 'default_allow_publishing',
			'enable_debug'
			));
		$propbag->add('groups', array('BACKEND_USERMANAGEMENT'));
	}

	function introspect_config_item($name, &$propbag)
	{
		switch($name)
		{
			case 'enable':
				$propbag->add('type',        'boolean');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_ENABLE);
				$propbag->add('description', PLUGIN_EVENT_LDAP_ENABLE_DESC);
				$propbag->add('default',     false);
				break;

			case 'host':
				$propbag->add('type',        'string');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_HOST);
				$propbag->add('description', PLUGIN_EVENT_LDAP_HOST_DESC);
				$propbag->add('default',     'localhost');
				break;

			case 'port':
				$propbag->add('type',        'string');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_PORT);
				$propbag->add('description', PLUGIN_EVENT_LDAP_PORT_DESC);
				$propbag->add('default',     '389');
				break;

			case 'rdn':
				$propbag->add('type',        'string');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_RDN);
				$propbag->add('description', PLUGIN_EVENT_LDAP_RDN_DESC);
				$propbag->add('default',     'uid=%1,ou=people,dc=yourdomain,dc=com');
				break;

			case 'tls':
				$propbag->add('type',        'boolean');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_TLS);
				$propbag->add('description', PLUGIN_EVENT_LDAP_TLS_DESC);
				$propbag->add('default',     false);
				break;

			case 'enable_sync':
				$propbag->add('type',        'boolean');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_SYNC);
				$propbag->add('description', PLUGIN_EVENT_LDAP_SYNC_DESC);
				$propbag->add('default',     false);
				break;
			
			case 'attr_password':
				$propbag->add('type',        'string');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_ATTR_PASSWORD);
				$propbag->add('description', PLUGIN_EVENT_LDAP_ATTR_PASSWORD_DESC);
				$propbag->add('default',     'userPassword');
				break;

			case 'attr_realname':
				$propbag->add('type',        'string');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_ATTR_REALNAME);
				$propbag->add('description', PLUGIN_EVENT_LDAP_ATTR_REALNAME_DESC);
				$propbag->add('default',     'displayName');
				break;

			case 'attr_email':
				$propbag->add('type',        'string');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_ATTR_EMAIL);
				$propbag->add('description', PLUGIN_EVENT_LDAP_ATTR_EMAIL_DESC);
				$propbag->add('default',     'mail');
				break;

			case 'attr_access_level':
				$propbag->add('type',        'string');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_ATTR_ACCESS_LEVEL);
				$propbag->add('description', PLUGIN_EVENT_LDAP_ATTR_ACCESS_LEVEL_DESC);
				$propbag->add('default',     'serendipityUserlevel');
				break;
				
			case 'default_access_level':
				$propbag->add('type',        'select');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_DEFAULT_ACCESS_LEVEL);
				$propbag->add('description', PLUGIN_EVENT_LDAP_DEFAULT_ACCESS_LEVEL_DESC);
				$propbag->add('default',     USERLEVEL_EDITOR);
				$propbag->add('select_values', array(
                                                USERLEVEL_ADMIN => USERLEVEL_EDITOR_DESC,
                                                USERLEVEL_CHIEF => USERLEVEL_CHIEF_DESC,
                                                USERLEVEL_EDITOR => USERLEVEL_ADMIN_DESC,
                                                -1 => PLUGIN_EVENT_LDAP_USERLEVEL_DENY));
				break;

			case 'default_wysiwyg':
				$propbag->add('type',        'boolean');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_DEFAULT_WYSIWYG);
				$propbag->add('description', PLUGIN_EVENT_LDAP_DEFAULT_WYSIWYG_DESC);
				$propbag->add('default',     false);
				break;

			case 'default_send_comments':
				$propbag->add('type',        'boolean');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_DEFAULT_SEND_COMMENTS);
				$propbag->add('description', PLUGIN_EVENT_LDAP_DEFAULT_SEND_COMMENTS_DESC);
				$propbag->add('default',     false);
				break;

			case 'default_send_trackback':
				$propbag->add('type',        'boolean');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_DEFAULT_SEND_TRACKBACK);
				$propbag->add('description', PLUGIN_EVENT_LDAP_DEFAULT_SEND_TRACKBACK_DESC);
				$propbag->add('default',     false);
				break;

			case 'default_forbid_creating':
				$propbag->add('type',        'boolean');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_DEFAULT_FORBID_CREATING);
				$propbag->add('description', PLUGIN_EVENT_LDAP_DEFAULT_FORBID_CREATING_DESC);
				$propbag->add('default',     false);
				break;

			case 'default_allow_publishing':
				$propbag->add('type',        'boolean');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_DEFAULT_ALLOW_PUBLISHING);
				$propbag->add('description', PLUGIN_EVENT_LDAP_DEFAULT_ALLOW_PUBLISHING_DESC);
				$propbag->add('default',     false);
				break;
			
			case 'enable_debug':
				$propbag->add('type',        'boolean');
				$propbag->add('name',        PLUGIN_EVENT_LDAP_DEBUG);
				$propbag->add('description', PLUGIN_EVENT_LDAP_DEBUG_DESC);
				$propbag->add('default',     false);
				break;
		}

		return true;
	}

	function generate_content(&$title)
	{
		$title = PLUGIN_EVENT_LDAP_TITLE;
	}

	function event_hook($event, &$bag, &$eventData, &$addData)
	{
		global $serendipity;

		$hooks = &$bag->get('event_hooks');
		if (isset($hooks[$event]))
		{
			switch($event)
			{
				case 'backend_auth':
					// When: If the user could not be authenticated natively.
					// Purpose: See if the user's credientials are in the LDAP directory.

					// Don't do anything if they have disabled LDAP authentication.
					if (!serendipity_db_bool($this->get_config('enable')))
						return true;
					
					$this->DebugMsg('Authenticating user: ' . $addData['username']);
					
					// If the password is already MD5'd, then we can't authenticate.  This is
					// no problem, because by now we've already authenticated the user anyway.
					if ($eventData === true)
					{
						$this->DebugMsg("LDAP: Can't authenticate; password encrypted (from cookie).");
						return true;
					}
					
					if ($this->AuthenticateUser($addData['username'], $addData['password']))
					{
						$_SESSION['serendipityCheckedLDAP'] = true;
					}
										
					return true;
					break;

				case 'backend_auth_verify':
					// When: If the user *could* be authenticated.
					// Purpose: Verify that the user still has a valid account in the LDAP directory.
					
					// Don't do anything if they have disabled LDAP authentication.
					if (!serendipity_db_bool($this->get_config('enable')))
						return true;
					
					// Don't verify accounts if synchronization is disabled.
					if (!serendipity_db_bool($this->get_config('enable_sync')))
						return true;
					
					// Only check once per session.
					if (isset($_SESSION['serendipityCheckedLDAP']))
						return true;
					
					// If the password is already MD5'd, then we can't authenticate.  This is
					// no problem, because by now we've already authenticated the user anyway.
					if ($eventData === true)
					{
						$this->DebugMsg("LDAP: Can't authenticate; password encrypted (from cookie).");
						return true;
					}
					
					$this->DebugMsg('Verifying existing account: ' . $addData['username']);
						
					if ($this->AuthenticateUser($addData['username'], $addData['password']))
					{
						$_SESSION['serendipityCheckedLDAP'] = true;
					}
					else
					{
						// If we failed to authenticate, then logout.							
						serendipity_logout();
					}
					
					return true;
					break;
				
				case 'backend_users_edit':
					// Don't do anything if they have disabled LDAP authentication or synchronization.
					if (!serendipity_db_bool($this->get_config('enable')) || !serendipity_db_bool($this->get_config('enable_sync')))
						return true;
					
					// Update the user's password.
					if (!empty($eventData['password']))
					{
						$this->UpdatePassword($eventData['username'], $eventData['check_password'], $eventData['password']);
					}
					
					return true;
					break;
					
				default:
					return false;
					break;					
			}
		}
		else
		{		
			return false;
		}
	}
	
	function LDAP_Connect()
	{
		if (!function_exists('ldap_connect'))
		{
			$this->DebugMsg('LDAP: No PHP support.');
			return false;
		}
		
		// Connect to the server.
		$host = $this->get_config('host');
		$port = $this->get_config('port');
		
		if (!empty($port))
		{
			$this->DebugMsg("LDAP: Connecting to $host on port $port.");
			$connection = @ldap_connect($host, $port);
		}
		else
		{
			$this->DebugMsg("LDAP: Connecting to $host on port 368.");
			$connection = @ldap_connect($host);
		}
		
		if ($connection === false)
		{
			$this->DebugMsg("LDAP: Failed to connect to server. " . ldap_error($connection));			
			return false;
		}
		
		// Setup TLS, if enabled.
		if (serendipity_db_bool($this->get_config('tls')))
		{
			$this->DebugMsg("LDAP: Using TLS.");
			
			@ldap_set_option($connection, LDAP_OPT_PROTOCOL_VERSION, 3);
			@ldap_start_tls($connection);
			
			if (ldap_errno($connection) != LDAP_SUCCESS)
				$this->DebugMsg("LDAP: TLS error. " . ldap_error($connection));
		}
		
		return $connection;
	}
	
	function LDAP_Bind($connection, $username, $password)
	{
		// Build the RDN string.
		$rdn = str_replace(array('%1', '%2', '%3'), array($username, $password, md5($password)), $this->get_config('rdn'));
		
		// Attempt to bind to the server.
		$this->DebugMsg("LDAP: Attempting to bind using $rdn.");
		if (!@ldap_bind($connection, $rdn, $password))
		{
			$this->DebugMsg("LDAP: Bind failed. " . ldap_error($connection));
			
			// Invalid user.
			return false;
		}
		else
		{
			$this->DebugMsg("LDAP: Bind successful.");
			return $rdn;
		}
	}
	
	function AuthenticateUser($username, $password)
	{
		global $serendipity;
		
		$this->DebugMsg("LDAP: Starting authentication process.");
		
		// Attempt to connect to the server.  If this failed, then their settings are incorrect.
		if (($connection = $this->LDAP_Connect()) === false)
			return false;
		
		if (($rdn = $this->LDAP_Bind($connection, $username, $password)) === false)
			return false;
		
		// Get the default values for the new user.
		$user_realname = $username;
		$user_email = '';
		$user_access_level = $this->get_config('default_access_level');
		$user_wysiwyg = serendipity_db_bool($this->get_config('default_wysiwyg'));
		$user_send_comments = serendipity_db_bool($this->get_config('default_send_comments'));
		$user_send_trackback = serendipity_db_bool($this->get_config('default_send_trackback'));
		$user_forbid_creating = serendipity_db_bool($this->get_config('default_forbid_creating'));
		$user_allow_publishing = serendipity_db_bool($this->get_config('default_allow_publishing'));	
		
		// Get the LDAP attribute names.c
		$attr_realname = $this->get_config('attr_realname');
		$attr_email = $this->get_config('attr_email');
		$attr_access_level = $this->get_config('attr_access_level');
		
		// Read some attributes from the database to create the new user.
		$attributes = array('objectclass',
							$attr_realname,
							$attr_email,
							$attr_access_level);
		
		if ($result = ldap_read($connection, $rdn, '(objectclass=*)', $attributes))
		{
			$entry = ldap_first_entry($connection, $result);
			$attr_values = @ldap_get_attributes($connection, $entry);
						
			if (count($attr_values[$attr_realname]) > 0)
				$user_realname = $attr_values[$attr_realname][0];
			
			if (count($attr_values[$attr_email]) > 0)
				$user_email = $attr_values[$attr_email][0];
			
			if (count($attr_values[$attr_access_level]) > 0)
				$user_access_level = $attr_values[$attr_access_level][0];
		}
		else
		{
			$this->DebugMsg("LDAP: Failed to read attributes.");
		}
		
		// See if the user is already in the database.
		$query = "SELECT DISTINCT authorid FROM {$serendipity['dbPrefix']}authors WHERE username = '" . serendipity_db_escape_string($username) . "'";
		$row = serendipity_db_query($query, true, 'assoc');
		
		if (is_array($row))
		{
			$this->DebugMsg("LDAP: Found user in S9Y.");
			
			// Edit the existing user.
			$authorid = $row['authorid'];
			
			// Update the user level.
			serendipity_set_user_var('userlevel', $user_access_level, $authorid);
			
			// Make sure the user's access is still enabled.
			if ($user_access_level < 0)
			{
				$this->DebugMsg("LDAP: Disabled account, invalidating password.");
				
				// Disable the account.
				serendipity_db_query("UPDATE {$serendipity['dbPrefix']}authors SET password = 'nothing' WHERE authorid = $authorid");
				return false;
			}
			else
			{
				serendipity_set_user_var('password', $password, $authorid);
				
				return true;
			}
		}
		else if ($user_access_level >= 0)
		{
			$this->DebugMsg("LDAP: New user account, adding to S9Y.");
			
			// If the user is enabled, add it to the database.
			$authorid = serendipity_addAuthor($username, $password, $user_realname, $user_email, $user_access_level);
			$new_user = true;
			
			// Save the user's default settings.
			serendipity_set_config_var('wysiwyg', $user_wysiwyg, $authorid);
			serendipity_set_user_var('mail_comments', $user_send_comments, $authorid);
			serendipity_set_user_var('mail_trackbacks', $user_send_trackback, $authorid);
			serendipity_set_config_var('no_create', $user_forbid_creating, $authorid);
			serendipity_set_user_var('right_publish', $user_allow_publishing, $authorid);
			
			return true;
		}
		
		return false;
	}
	
	function UpdatePassword($username, $password_old, $password_new)
	{
		$this->DebugMsg("LDAP: Updating password.");
		
		// Attempt to connect to the server.  If this failed, then their settings are incorrect.
		if (($connection = $this->LDAP_Connect()) === false)
			return true;
		
		// First we need to bind using the old password.
		if (($rdn = $this->LDAP_Bind($connection, $username, $password_old)) === false)
			return false;
		
		// Get the LDAP attribute names.
		$attr_password = $this->get_config('attr_password');
		
		// Update various attributes.  Currently only the password, but we could update the
		// e-mail, name, etc as well.		
		$update_attrs = array();
		
		if ($attr_password)
			$update_attrs[$attr_password] = '{md5}' . $this->md5_base64($password_new);
		
		if (@ldap_mod_replace($connection, $rdn, $update_attrs) === false)
		{
			$this->DebugMsg("LDAP: Failed to update attributes. " . ldap_error($connection));
			return false;
		}
		else
		{
			$this->DebugMsg("LDAP: Update complete.");
			return true;
		}		
	}
	
	function md5_base64($string)
	{
		$base16 = md5($string);
		$base256 = '';
		
		for ($i = 0; $i < strlen($base16); $i +=2)
			$base256 .= chr(hexdec(substr($base16, $i, 2)));
		
		return base64_encode($base256);
	}
	
	function DebugMsg($msg)
	{
		if (serendipity_db_bool($this->get_config('enable_debug')))
		{
			$fp = fopen('/tmp/s9yldap.log', 'a');
			fwrite($fp, '[' . date('d.m.Y H:i') . '] ' . $msg . "\n");
			fclose($fp);
		}
	}
}

?>