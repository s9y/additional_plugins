// Copyright (c) 2006 Bernd Lackinger (AzRAeL) (http://www.warpzone.at)
// 
// this script uses: 
//      Prototype (c) 2005 Sam Stephenson
//      Scriptaculous (c) 2005 Thomas Fuchs
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

/* use onDOMReady instead of onload
 * massively speeds up page-load-event
 *  (doesn't wait for images to load)
 */

dt=new Date(); /* init loadtimer */

Event.onDOMReady(function() {
  if(SidebarItemCollapseConfiguration.activeExpandCollapse){ initSidebars(); }
  if(SidebarItemCollapseConfiguration.activeDragDrop){ initSortables();}
});

function initSidebars(){
  var menuItemsTitleLeft = document.getElementsByClassName("serendipitySideBarTitle", document.getElementById("serendipityLeftSideBar") );
  
  // 1st check if available
  var menuItemsLeft = document.getElementById("serendipityLeftSideBar") ? document.getElementsByClassName("serendipitySideBarContent" , document.getElementById("serendipityLeftSideBar")) : null;
  
  var menuItemsTitleRight = document.getElementsByClassName("serendipitySideBarTitle", document.getElementById("serendipityRightSideBar") );
  
  // 1st check if available
  var menuItemsRight = document.getElementById("serendipityRightSideBar") ? document.getElementsByClassName("serendipitySideBarContent", document.getElementById("serendipityRightSideBar")) : null;
    
  /* give ids to those who do not have one ;-) */
  var allItems = document.getElementsByClassName("serendipitySideBarContent");
  for(var i=0;i<allItems.length;i++){
      if(!allItems[i].id){
        allItems[i].id = IdForObj(allItems[i].parentNode) +"_"+ IdForObj(allItems[i]);
      }
  }

  /* prevent visible clipping - use an effect to hide unused items*/
  var loaddelayed = ((new Date() - dt)/1000)>0.5 ? true : false;

  /* all left sidebaritems */
  if(menuItemsLeft){
    for(var i=0; i<menuItemsLeft.length; i++){
      if(menuItemsTitleLeft[i]){
        Try.these(
          function() {menuItemsTitleLeft[i].addEventListener('click', function () { toggleContent(this,'left'); },false);},
          function() {menuItemsTitleLeft[i].attachEvent('onclick',  function () { toggleContent(event.srcElement,'left'); }  )}
    		);
        
        var contentId = document.getElementsByClassName("serendipitySideBarContent" , menuItemsLeft[i].parentNode)[0].id;
        var viewstate = readCookie(contentId + "__viewstate");
        if(viewstate=="hidden"){
          if(!loaddelayed){
            Element.hide( menuItemsLeft[i] );
          }else{
            new Effect.BlindUp(menuItemsLeft[i], {duration:SidebarItemCollapseConfiguration.delayedHideDuration});
          }
          appendTitleCss(menuItemsTitleLeft[i] , false);
        }else{
          /* show by default*/
          appendTitleCss(menuItemsTitleLeft[i] , true);        
        }
      }
    }
  }
  
  /* all right sidebaritems */
  if(menuItemsRight){
    for(var i=0; i<menuItemsRight.length; i++){
      if(menuItemsTitleRight[i]){
       Try.these(
      		function() {menuItemsTitleRight[i].addEventListener('click', function () { toggleContent(this,'right') },false);},
      		function() {menuItemsTitleRight[i].attachEvent('onclick',  function () { toggleContent(event.srcElement,'right'); }  )}
    		);
    		
        var contentId = document.getElementsByClassName("serendipitySideBarContent" , menuItemsRight[i].parentNode)[0].id;
        var viewstate = readCookie(contentId + "__viewstate");
        if(viewstate=="hidden"){
          if(!loaddelayed){
            Element.hide( menuItemsRight[i] );
          }else{
            new Effect.BlindUp(menuItemsRight[i], {duration:SidebarItemCollapseConfiguration.delayedHideDuration});
          }
          appendTitleCss(menuItemsTitleRight[i] , false);
        }else{
          /* show by default*/
          appendTitleCss(menuItemsTitleRight[i] , true);
        }     
      }
    }
  }
}

function appendTitleCss(obj, expanded){
  try{
    if(expanded){
      if(SidebarItemCollapseConfiguration.useCSSClassNames){
        Element.addClassName(obj, SidebarItemCollapseConfiguration.sidebar_item_collapse_expanded);
        Element.removeClassName(obj, SidebarItemCollapseConfiguration.sidebar_item_collapse_collapsed);
      }else{
        Element.setStyle(obj, getcssPropertyHash(SidebarItemCollapseConfiguration.sidebar_item_collapse_expanded) );
      }
    }else{
      if(SidebarItemCollapseConfiguration.useCSSClassNames){
        Element.addClassName(obj, SidebarItemCollapseConfiguration.sidebar_item_collapse_collapsed);
        Element.removeClassName(obj, SidebarItemCollapseConfiguration.sidebar_item_collapse_expanded);
      }else{
        Element.setStyle(obj, getcssPropertyHash(SidebarItemCollapseConfiguration.sidebar_item_collapse_collapsed) );
      }
    }
  }catch(e){
    /* IE with "! important" throws error*/
  }
}

function getcssPropertyHash(s){
  /* generate Hash of CSSCode */
  /* 2do: cache processed hashes... if necessary */
  var styleHash = $H( new Object );
	var styleProps = s.split(";");

	for(var i=0;i<styleProps.length;i++){
    var pair = styleProps[i].split(":");
    if(pair.length==2 && pair[0]!=""){
      var propObject= new Object;
          propObject[ str_replace(" ","",pair[0]) ] = pair[1];
      styleHash = styleHash.merge($H(propObject));
    }
  }
  return styleHash;
}

function initSortables(){

  var menuItemsLeft = document.getElementsByClassName("serendipitySideBarItem" , document.getElementById("serendipityLeftSideBar"));
  var menuItemsRight = document.getElementsByClassName("serendipitySideBarItem", document.getElementById("serendipityRightSideBar"));
  
  var allItems = menuItemsLeft.concat(menuItemsRight);

  for(var i=0;i<allItems.length;i++){
      if(!allItems[i].id){
        allItems[i].id = IdForObj(allItems[i]);
      }
  }
    
  reorderSortables(menuItemsLeft, menuItemsRight);
  
  if($('serendipityLeftSideBar'))  Sortable.create('serendipityLeftSideBar' ,{tag:'div',only:'serendipitySideBarItem', onUpdate:updateItemOrderLeft});
  if($('serendipityRightSideBar')) Sortable.create('serendipityRightSideBar',{tag:'div',only:'serendipitySideBarItem', onUpdate:updateItemOrderRight});
}

function updateItemOrderRight(el){
  updateItemOrder(el,"Right");
}

function updateItemOrderLeft(el){
  updateItemOrder(el,"Left");
}

function updateItemOrder(htmlItem,side){
	var items = $A(document.getElementsByClassName("serendipitySideBarItem", document.getElementById("serendipity"+side+"SideBar")));
  for(var i=0;i<items.length;i++){
    createCookie(items[i].id, i ,"1000");
  }
}

function reorderSortables(menuItemsLeft, menuItemsRight){

  if($('serendipityLeftSideBar')){
    for(var i=0;i<menuItemsLeft.length;i++){
        var moveto = readCookie(menuItemsLeft[i].id);
        var menuItemsLeftRefreshed = document.getElementsByClassName("serendipitySideBarItem" , document.getElementById("serendipityLeftSideBar"));
        try{
          document.getElementById("serendipityLeftSideBar").insertBefore( menuItemsLeft[i], menuItemsLeftRefreshed[moveto]);
        }catch(e){
          //log("error: "+i+" > "+moveto);
        }
    }
  }

  if($('serendipityRightSideBar')){
    for(var i=0;i<menuItemsRight.length;i++){
        var moveto = readCookie(menuItemsRight[i].id);
        var menuItemsRightRefreshed = document.getElementsByClassName("serendipitySideBarItem" , document.getElementById("serendipityRightSideBar"));
        try{
          document.getElementById("serendipityRightSideBar").insertBefore(menuItemsRight[i], menuItemsRightRefreshed[moveto]);
        }catch(e){
          //log("error: "+i+" > "+moveto);
        }
    }
  }
}

function IdForObj(obj){
  var itsId = "undefined";
  if(obj.id){
    itsId=obj.id;
  }else{
    itsId=str_replace(" ", "__", obj.className);
  }
  return itsId;
}

function log(text){
  //$("serendipity_banner").innerHTML += text+"<br />\n";
}

function toggleContent(header, side){
  var targetDiv;
  var sideObj;
  var myItems = new Array();

  if(header){
    targetDiv = document.getElementsByClassName("serendipitySideBarContent" , header.parentNode)[0];
  }
  
  if(side=="left"){
    sideObj = document.getElementById("serendipityLeftSideBar");
  }else if(side=="right"){
    sideObj = document.getElementById("serendipityRightSideBar");
  }

  var menuItems = document.getElementsByClassName("serendipitySideBarContent" , sideObj);
  
  for(var i=0; i<menuItems.length;i++){
    var viewstate = "hidden";
    var currItem = menuItems[i];
    var applyStyleTo = document.getElementsByClassName("serendipitySideBarTitle" , currItem.parentNode)[0];
    
    if(menuItems[i]==targetDiv){
      /* when clicked */
      if(!Element.visible(currItem)){
          new Effect.BlindDown(currItem, {duration:SidebarItemCollapseConfiguration.xfDuration});
          appendTitleCss(applyStyleTo , true);  
          viewstate="visible";
      }else{
        if(SidebarItemCollapseConfiguration.MultipleActive==true){
          new Effect.BlindUp(currItem, {duration:SidebarItemCollapseConfiguration.xfDuration});
          appendTitleCss(applyStyleTo , false); 
        }
        viewstate="hidden";
      }
    }else{
      /* when automatically toggled */
      if(Element.visible(currItem)){
        if(SidebarItemCollapseConfiguration.MultipleActive == false){
          new Effect.BlindUp(currItem, {duration:SidebarItemCollapseConfiguration.xfDuration});
          appendTitleCss(applyStyleTo , false); 
          viewstate="hidden";
        }else{
          viewstate="visible";
        }
      }else{
        viewstate="hidden";
      }
    }
    createCookie(currItem.id+"__viewstate" , viewstate,"1000");
  }
}
