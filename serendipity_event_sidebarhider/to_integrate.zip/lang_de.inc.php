<?php

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_NAME', 'Sidebar Item Collapser');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_DESC', 'Ein- und Ausblenden vom Serendipity Seitenleisten Einträgen per Javascript');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVE_NAME', 'Plugin aktivieren?');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVE_DESC', 'Diesen Plugin aktivieren?');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEDRAGDROP_NAME', 'Drag&Drop aktivieren?');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEDRAGDROP_DESC', 'Neuanordnen von Blöcken in den Seitenleisten per Drag&Drop zulassen?');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEEXPANDCOLLAPSE_NAME', 'Anzeigen/Verbergen aktivieren?');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEEXPANDCOLLAPSE_DESC', 'Anzeigen/Verbergen von Blöcken in den Seitenleisten aktivieren?');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_FXDURATION_NAME', 'Effekt-Dauer');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_FXDURATION_DESC', 'Geben Sie die dauer des Effektes zum Anzeigen/Verbergen in Sekunden ein (z.B: 0.5 , 1 or 2)');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_FXDURATION_ERROR', 'Bitte eine Zahl eingeben');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_DELAYEDHIDEDURATION_NAME', 'Ladeverzögerte Effektdauer');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_DELAYEDHIDEDURATION_DESC', 'Geben Sie die Dauer des Effektes zum Verbergen der Blöcke beim Laden der Seite ein. Dies wird benützt wenn das Laden des scriptes länger als 0.5 Sekunden dauert und dadurch optisch unschöne Effekte beim sofortigen Ausblenden auftreten würden. Anstatt die Blöcke sofort auszuschalten wird ein Effekt zum Ausblenden benützt.');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEMODE_NAME', 'Multiple aktive Blöcke zulassen?');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEMODE_DESC', 'Wählen Sie, ob multiple aktive Blöcke pro Seitenleiste zulässig sind');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_EXPANDEDCSSCLASS_NAME','CSS-Klasse / CSS-Code für expandierte Blöcke');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_EXPANDEDCSSCLASS_DESC','Name der CSS-Klasse bzw direkt CSS-Code für expandierte Blöcke angeben. Dieser wird zusätzlich an den serendipitySideBarTitle angefügt um z.B ein + oder - als Hintergrundbild einzufügen. Um NICHTS einzugeben bitte ein Leerzeichen angeben. Wenn hier Code verwendet muss auch bei obenstehender Option Code verwenden und vice versa. Internetexplorer verträgt die Angabe von "! important" an dieser Stelle nicht ;-(');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_COLLAPSEDCSSCLASS_NAME','CSS-Klasse / CSS-Code für verborgene Blöcke');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_COLLAPSEDCSSCLASS_DESC','Name der CSS-Klasse bzw direkt CSS-Code für verborgene Blöcke angeben. Dieser wird zusätzlich an den serendipitySideBarTitle angefügt um z.B ein + oder - als Hintergrundbild einzufügen. Um NICHTS einzugeben bitte ein Leerzeichen angeben. Wenn hier Code verwendet muss auch bei nachstehender Option Code verwenden und vice versa. Internetexplorer verträgt die Angabe von "! important" an dieser Stelle nicht ;-(');

?>
