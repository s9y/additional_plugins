<?php

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_NAME', 'Sidebar Item Collapser');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_DESC', 'Collapses items in your serendipity sidebar using Javascript');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVE_NAME', 'Activate plugin?');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVE_DESC', 'Activate this plugin?');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEDRAGDROP_NAME', 'Activate drag&drop?');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEDRAGDROP_DESC', 'Activate reordering of sidebarItems via drag&drop?');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEEXPANDCOLLAPSE_NAME', 'Activate hiding?');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEEXPANDCOLLAPSE_DESC', 'Activate hiding of sidebarItems?');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_FXDURATION_NAME', 'Effect-duration');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_FXDURATION_DESC', 'Enter the duration of hide/show effect in seconds (eg 0.5 , 1 or 2)');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_FXDURATION_ERROR', 'please enter a number');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_DELAYEDHIDEDURATION_NAME', 'delayed-hide-duration');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_DELAYEDHIDEDURATION_DESC', 'Enter the duration of the hide effect on pageload - this is used then script loading takes too long and visual clipping would occur when hiding items - so a smooth fade effect is used instead');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEMODE_NAME', 'Use multiple active Items?');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEMODE_DESC', 'Select wether or not the user should be able to activate multiple items per sidebar');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_EXPANDEDCSSCLASS_NAME','expanded item CSS-class / CSS-code');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_EXPANDEDCSSCLASS_DESC','CSS-class-name / CSS-code for expanded items which will be applied to serendipitySideBarTitle. To set nothing, neither the default values, just enter a space. If you use code/classname here, also use code/classname in the other option. Currently IE breaks with "! important" ;-(');

@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_COLLAPSEDCSSCLASS_NAME','collapsed item CSS-class / CSS-code');
@define('PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_COLLAPSEDCSSCLASS_DESC','CSS-class-name / CSS-code for collapsed items which will be applied to serendipitySideBarTitle. To set nothing, neither the default values, just enter a space. If you use code/classname here, also use code/classname in the other option. Currently IE breaks with "! important" ;-(');

?>
