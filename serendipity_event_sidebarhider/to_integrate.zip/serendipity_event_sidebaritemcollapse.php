<?php

// Probe for a language include with constants. Still include defines later on, if some constants were missing
$probelang = dirname(__FILE__) . '/' . $serendipity['charset'] . 'lang_' . $serendipity['lang'] . '.inc.php';
if (file_exists($probelang)) {
    include $probelang;
}else{
  include dirname(__FILE__) . '/lang_en.inc.php';
}

class serendipity_event_sidebaritemcollapse extends serendipity_event {
    var $title = "serendipity_event_sidebaritemcollapse";

    function introspect(&$propbag)
    {
        $this->title = PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_NAME;

        $propbag->add('name',          PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_NAME);
        $propbag->add('description',   PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_DESC);
        $propbag->add('stackable',     false);
        $propbag->add('author',        'Bernd Lackinger');
        $propbag->add('version',       '0.9.1');
        $propbag->add('requirements',  array(
            'serendipity' => '0.8',
            'smarty'      => '2.6.7',
            'php'         => '4.1.0'
        ));

        $propbag->add('groups', array('FRONTEND_FEATURES'));
        $propbag->add('cachable_events', array('frontend_header' => true));
        $propbag->add('event_hooks',   array('frontend_header' => true));
        $propbag->add('configuration', array('active','activeDragDrop','activeExpandCollapse','fxDuration','delayedHideDuration','sidebar_item_collapse_collapsed','sidebar_item_collapse_expanded','activeMode'));
    }

    function introspect_config_item($name, &$propbag)
    {
       switch($name) {
            case 'active':
                $propbag->add('type',        'boolean');
                $propbag->add('name',        PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVE_NAME);
                $propbag->add('description', PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVE_DESC);
                $propbag->add('default',     true);
                break;
            
            case 'fxDuration':
                $propbag->add('type',        'string');
                $propbag->add('name',        PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_FXDURATION_NAME);
                $propbag->add('description', PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_FXDURATION_DESC);
                $propbag->add('default',     '0.5');
                break;
                
            case 'delayedHideDuration':
                $propbag->add('type',        'string');
                $propbag->add('name',        PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_DELAYEDHIDEDURATION_NAME);
                $propbag->add('description', PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_DELAYEDHIDEDURATION_DESC);
                $propbag->add('default',     '2');
                break;

            case 'sidebar_item_collapse_collapsed':
                $propbag->add('type',        'string');
                $propbag->add('name',        PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_COLLAPSEDCSSCLASS_NAME);
                $propbag->add('description', PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_COLLAPSEDCSSCLASS_DESC);
                $propbag->add('default',     'cursor:s-resize');
                break;
                
            case 'sidebar_item_collapse_expanded':
                $propbag->add('type',        'string');
                $propbag->add('name',        PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_EXPANDEDCSSCLASS_NAME);
                $propbag->add('description', PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_EXPANDEDCSSCLASS_DESC);
                $propbag->add('default',     'cursor:n-resize');
                break;

            case 'activeDragDrop':
                $propbag->add('type',        'boolean');
                $propbag->add('name',        PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEDRAGDROP_NAME);
                $propbag->add('description', PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEDRAGDROP_DESC);
                $propbag->add('default',     true);
                break;

            case 'activeExpandCollapse':
                $propbag->add('type',        'boolean');
                $propbag->add('name',        PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEEXPANDCOLLAPSE_NAME);
                $propbag->add('description', PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEEXPANDCOLLAPSE_DESC);
                $propbag->add('default',     true);
                break;

            case 'activeMode':
                $propbag->add('type',        'boolean');
                $propbag->add('name',        PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEMODE_NAME);
                $propbag->add('description', PLUGIN_EVENT_SIDEBARITEMCOLLAPSE_OPTIONS_ACTIVEMODE_DESC);
                $propbag->add('default',     true);
                break;

            default:
                return false;
        }
        return true;
    }

    function install() {
        serendipity_plugin_api::hook_event('backend_cache_entries', $this->title);
    }

    function uninstall() {
        serendipity_plugin_api::hook_event('backend_cache_purge', $this->title);
        serendipity_plugin_api::hook_event('backend_cache_entries', $this->title);
    }

    function generate_content(&$title) {
        $title = $this->title;
    }

    function event_hook($event, &$bag, &$eventData) {
        global $serendipity;

        $hooks = &$bag->get('event_hooks');
        $version = &$bag->get('version');
        $active = $this->get_config('active');
        $activeMode = $this->get_config('activeMode')==1 ? "true" : "false";
        $fxDuration = $this->get_config('fxDuration');
        $delayedHideDuration = $this->get_config('delayedHideDuration');
        $activeDragDrop = $this->get_config('activeDragDrop')==1 ? "true" : "false";
        $activeExpandCollapse = $this->get_config('activeExpandCollapse')==1 ? "true" : "false";
        $sidebar_item_collapse_collapsed = $this->get_config('sidebar_item_collapse_collapsed');
        $sidebar_item_collapse_expanded = $this->get_config('sidebar_item_collapse_expanded');
        $useCSSClasses = strpos($sidebar_item_collapse_collapsed, ":") > 0 ? "false":"true";
        
        if($active == true){

          if (isset($hooks[$event])) {
            switch($event) {
              case 'frontend_header':
                  $plugin_dir = $serendipity['serendipityHTTPPath']."plugins/".basename(dirname(__FILE__));
                  
                  echo ' <script type="text/javascript">'. "\n";
                  echo '  var SidebarItemCollapseConfiguration = {'. "\n";
                  echo '      Version: "'.$version.'",'. "\n";
                  echo '      xfDuration : Math.abs('.$fxDuration.'),'. "\n";
                  echo '      delayedHideDuration : Math.abs('.$delayedHideDuration.'),'. "\n";
                  echo '      PluginPath : "'.$plugin_dir.'",'. "\n";
                  echo '      activeDragDrop : '.$activeDragDrop.','. "\n";
                  echo '      activeExpandCollapse : '.$activeExpandCollapse.','. "\n";
                  echo '      MultipleActive : '.$activeMode.','. "\n";
                  echo '      sidebar_item_collapse_collapsed : "'.$sidebar_item_collapse_collapsed.'",'. "\n";
                  echo '      sidebar_item_collapse_expanded : "'.$sidebar_item_collapse_expanded.'",'. "\n";
                  echo '      useCSSClassNames : '.$useCSSClasses . ''. " \n";
                  echo '  }'. "\n";
                  echo ' </script>'. "\n";
                  /*
                  echo ' <style type="text/css">'. "\n";
                  echo '   .testactive{ color:red ! important }'. "\n";
                  echo '   .testinactive{ color:blue ! important }'. "\n";
                  echo ' </style>'. "\n";
                  */
                  echo ' <script type="text/javascript" src="'.$plugin_dir.'/js/loader.js"></script>'. "\n";
                  return true;
                  break;

              default:
                return false;
            }
          } else {
              return false;
          }
        }
    }
    
}

?>
